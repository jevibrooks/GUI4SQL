/**
*/
public class JDBCTestMain
{
	public static void main(String[] args) 
	{
		JDBCTest dataBaseAccess = new JDBCTest();
	}
}
