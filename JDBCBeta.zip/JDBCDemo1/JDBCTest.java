/**
 */
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Container;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;

public class  JDBCTest extends JFrame 
{
    // the database connector details  
    static final String DRIVER = "com.mysql.jdbc.Driver"; // JDBC driver
    static final String DATABASE = "test"; // the database name
    static final String HOST = "10.1.63.200"; // the database host IP

    // the full URL:
    static final String DATABASE_URL =
        "jdbc:mysql://" + HOST + "/" + DATABASE;

    public Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;
    String results = null;
    String password = null;
    String user = null;
    String sqlQuery = null;
    JTextField userName, query = null;
    JPasswordField passwordName = null;
    JTextArea outputArea = null;
    Container con = null;
    JLabel userL, passwordL,emptyL, queryL = null;
    JButton loginButton = null;

    // launch the application
    public JDBCTest()
    {
        super("JDBC access");
        userName = new JTextField(10);
        userL = new JLabel("Enter user name => ");
        passwordL = new JLabel("Enter password=> ");
        queryL = new JLabel("Enter SQL query=> ");
        query = new JTextField(10);
        query.setText("SELECT AuthorID, FirstName, LastName FROM Authors");
        emptyL = new JLabel("");
        passwordName = new JPasswordField(10);
        outputArea = new JTextArea(30,50);
        loginButton = new JButton("Login and Execute Query");
        con = getContentPane();
        con.setLayout(new GridLayout(5,2));
        con.add(userL);
        con.add(userName);
        con.add(passwordL);
        con.add(passwordName);
        con.add(queryL);
        con.add(query);
        con.add(loginButton);
        con.add(emptyL);
        con.add(outputArea);
        loginButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    user = userName.getText();
                    password = passwordName.getText();
                    sqlQuery = query.getText();

                    /* Try to connect but don't print error message 
                    setConnection();
                    outputArea.setText(getData());
                     */

                    /* Print error message */
                    boolean connectionSet = setConnection();
                    if (connectionSet) outputArea.setText(getData());
                    else outputArea.setText("ERROR establishing connection! Please consult stack trace.");   
                }
            });

        pack();
        setLocation(210,150);
        setSize(500, 500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Returns true if connection could be established, false otherwise
     */
    public boolean setConnection()
    {
        boolean connectionOK = false;
        // connect to database 
        try 
        {
            // load the driver class
            Class.forName(DRIVER);
            // establish connection to database    
            connection =  DriverManager.getConnection(DATABASE_URL, user, password);
            connectionOK = true;  // never reached if exception thrown
        }
        catch (SQLException sqlException)                                
        {       
            System.err.println("Driver loaded, but something went wrong elsewhere!");               
            sqlException.printStackTrace();

        } // end catch                                                     
        catch (ClassNotFoundException classNotFound)                     
        {                        
            System.err.println("Couldn't find driver!");
            classNotFound.printStackTrace();            
        } // end catch                             

        return connectionOK;
    }

    public String getData()
    {
        try 
        {
            // create Statement for querying database
            statement = connection.createStatement();

            // query database                                        
            //resultSet = statement.executeQuery("SELECT AuthorID, FirstName, LastName FROM Authors");
            resultSet = statement.executeQuery(sqlQuery);

            // process query results
            ResultSetMetaData metaData = resultSet.getMetaData();
            int numberOfColumns = metaData.getColumnCount();     
            results = "Authors Table of Books Database:\n";

            // print the column headers
            for (int i = 1; i <= numberOfColumns; i++)
            {
                results += metaData.getColumnName(i) + '\t' ; 
            }
            results += '\n';

            // extract the results
            while (resultSet.next()) 
            {
                for (int i = 1; i <= numberOfColumns; i++)
                {
                    results += resultSet.getObject(i).toString()  + '\t';
                }
                results += '\n';
            } // end while
        }  // end try
        catch (SQLException sqlException)                                
        {                                                                  
            sqlException.printStackTrace();
            // Print an error message instead of results
            results = "ERROR! Something went wrong, please consult stack trace!";
        } // end catch                                                     
        finally // ensure resultSet, statement and connection are closed
        {                                                             
            try                                                        
            {                                                          
                resultSet.close();                                      
                statement.close();                                      
                connection.close();                                     
            } // end try                                               
            catch (Exception exception)                              
            {                                                          
                exception.printStackTrace();                            
            } // end catch                                             
        } // end finally      
        return results;
    } 
}
